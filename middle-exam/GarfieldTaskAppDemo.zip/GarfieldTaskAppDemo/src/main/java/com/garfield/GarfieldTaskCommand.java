package com.garfield;

import picocli.CommandLine.Command;

// This is the main command. Students will add subcommands to it.
@Command(
    name = "GarfieldTask",
    version = "GarfieldTask 1.0",
    mixinStandardHelpOptions = true, // Adds --help and --version options
    description = "A command-line tool to help Garfield manage his tasks."
)
public class GarfieldTaskCommand {
    // This class acts as a container for all other commands.
    // Students will need to pass the repository and other services
    // into the constructors of their real command classes.
}
